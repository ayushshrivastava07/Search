package com.cg.ftf.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="query_master_1")
public class Query2 {
	@Id
	@NotNull(message="Query ID is mandatory.") @Min(1) @Max(4)
	@Column(name="query_id")
	private Integer queryId;
	
	@Column(name="technology")
	private String technology;
	
	@Column(name="query_raised_by")
	private String queryRaisedBy;
	
	@Column(name="query")
	private String query;

	public Integer getQueryId() {
		return queryId;
	}

	public void setQueryId(Integer queryId) {
		this.queryId = queryId;
	}

	public String getTechnology() {
		return technology;
	}

	public void setTechnology(String technology) {
		this.technology = technology;
	}

	public String getQueryRaisedBy() {
		return queryRaisedBy;
	}

	public void setQueryRaisedBy(String queryRaisedBy) {
		this.queryRaisedBy = queryRaisedBy;
	}

	public String getQuery() {
		return query;
	}

	public void setQuery(String query) {
		this.query = query;
	}
	
}
